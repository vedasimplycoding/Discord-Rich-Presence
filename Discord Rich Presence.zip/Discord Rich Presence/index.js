var rpc = require("discord-rpc")
const client = new rpc.Client({ transport: 'ipc' })
client.on('ready', () => {
	client.request('SET_ACTIVITY', {
		pid: process.pid,
		activity : {
			details : "____________",
			assets : {
				large_image : "_________",
				large_text : "__________"
			},
			buttons : [{label : "________" , url : "__________________"},{label : "_______________" , url : "https://discord.gg/A4HUVbktP3"}]
		}
	})
})
client.login({ clientId : "_____________" }).catch(console.error);
